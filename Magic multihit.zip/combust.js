import combust_1 from './combust_1.js';
import combust_2 from './combust_2.js';
import combust_3 from './combust_3.js';
import combust_4 from './combust_4.js';
import combust_5 from './combust_5.js';

function combust(type, settings, numberOfHits) {
    const hitOne = combust_1(type,settings,1);
    const hitTwo = combust_2(type,settings,1);
	const hitThree = combust_3(type,settings,1);
	const hitFour = combust_4(type,settings,1);
	const hitFive= combust_5(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1] + hitFour[hitFour.length-1] + hitFive[hitFive.length-1]];
}

export default combust;