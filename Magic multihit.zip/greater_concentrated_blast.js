import greater_concentrated_blast_1 from './greater_concentrated_blast_1.js';
import greater_concentrated_blast_2 from './greater_concentrated_blast_2.js';
import greater_concentrated_blast_3 from './greater_concentrated_blast_3.js';

function greater_concentrated_blast(type, settings, numberOfHits) {
    const hitOne = greater_concentrated_blast_1(type,settings,1);
    const hitTwo = greater_concentrated_blast_2(type,settings,1);
	const hitThree = greater_concentrated_blast_3(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1]];
}

export default greater_concentrated_blast;