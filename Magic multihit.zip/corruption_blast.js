import corruption_blast_1 from './corruption_blast_1.js';
import corruption_blast_2 from './corruption_blast_2.js';
import corruption_blast_3 from './corruption_blast_3.js';
import corruption_blast_4 from './corruption_blast_4.js';
import corruption_blast_5 from './corruption_blast_5.js';

function corruption_blast(type, settings, numberOfHits) {
    const hitOne = corruption_blast_1(type,settings,1);
    const hitTwo = corruption_blast_2(type,settings,1);
	const hitThree = corruption_blast_3(type,settings,1);
	const hitFour = corruption_blast_4(type,settings,1);
	const hitFive= corruption_blast_5(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1] + hitFour[hitFour.length-1] + hitFive[hitFive.length-1]];
}

export default corruption_blast;