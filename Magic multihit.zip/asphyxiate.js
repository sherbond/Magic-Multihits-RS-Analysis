import asphyxiate_1 from './asphyxiate_1.js';
import asphyxiate_2 from './asphyxiate_2.js';
import asphyxiate_3 from './asphyxiate_3.js';
import asphyxiate_4 from './asphyxiate_4.js';

function asphyxiate(type, settings, numberOfHits) {
    const hitOne = asphyxiate_1(type,settings,1);
    const hitTwo = asphyxiate_2(type,settings,1);
	const hitThree = asphyxiate_3(type,settings,1);
	const hitFour = asphyxiate_4(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1] + hitFour[hitFour.length-1]];
}

export default asphyxiate;