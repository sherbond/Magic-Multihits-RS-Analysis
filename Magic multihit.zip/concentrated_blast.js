import concentrated_blast_1 from './concentrated_blast_1.js';
import concentrated_blast_2 from './concentrated_blast_2.js';
import concentrated_blast_3 from './concentrated_blast_3.js';

function concentrated_blast(type, settings, numberOfHits) {
    const hitOne = concentrated_blast_1(type,settings,1);
    const hitTwo = concentrated_blast_2(type,settings,1);
	const hitThree = concentrated_blast_3(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1]];
}

export default concentrated_blast;