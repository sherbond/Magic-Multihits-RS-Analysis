import armadyl_battlestaff_1 from './armadyl_battlestaff_1.js';
import armadyl_battlestaff_2 from './armadyl_battlestaff_2.js';
import armadyl_battlestaff_3 from './armadyl_battlestaff_3.js';
import armadyl_battlestaff_4 from './armadyl_battlestaff_4.js';
import armadyl_battlestaff_5 from './armadyl_battlestaff_5.js';

function armadyl_battlestaff(type, settings, numberOfHits) {
    const hitOne = armadyl_battlestaff_1(type,settings,1);
    const hitTwo = armadyl_battlestaff_2(type,settings,1);
	const hitThree = armadyl_battlestaff_3(type,settings,1);
	const hitFour = armadyl_battlestaff_4(type,settings,1);
	const hitFive= armadyl_battlestaff_5(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1] + hitFour[hitFour.length-1] + hitFive[hitFive.length-1]];
}

export default armadyl_battlestaff;