import omnipower_igneous_1 from './omnipower_igneous_1.js';
import omnipower_igneous_2 from './omnipower_igneous_2.js';
import omnipower_igneous_3 from './omnipower_igneous_3.js';
import omnipower_igneous_4 from './omnipower_igneous_4.js';

function omnipower_igneous(type, settings, numberOfHits) {
    const hitOne = omnipower_igneous_1(type,settings,1);
    const hitTwo = omnipower_igneous_2(type,settings,1);
	const hitThree = omnipower_igneous_3(type,settings,1);
	const hitFour = omnipower_igneous_4(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1] + hitFour[hitFour.length-1]];
}

export default omnipower_igneous;