import wild_magic_1 from './wild_magic_1.js';
import wild_magic_2 from './wild_magic_2.js';

function wild_magic(type, settings, numberOfHits) {
    const hitOne = wild_magic_1(type,settings,1);
    const hitTwo = wild_magic_2(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1]];
}

export default wild_magic;