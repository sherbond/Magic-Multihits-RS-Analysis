import magma_tempest_1 from './magma_tempest_1.js';
import magma_tempest_2 from './magma_tempest_2.js';
import magma_tempest_3 from './magma_tempest_3.js';
import magma_tempest_4 from './magma_tempest_4.js';
import magma_tempest_5 from './magma_tempest_5.js';
import magma_tempest_6 from './magma_tempest_6.js';
import magma_tempest_7 from './magma_tempest_7.js';
import magma_tempest_8 from './magma_tempest_8.js';

function magma_tempest(type, settings, numberOfHits) {
    const hitOne = magma_tempest_1(type,settings,1);
    const hitTwo = magma_tempest_2(type,settings,1);
	const hitThree = magma_tempest_3(type,settings,1);
	const hitFour = magma_tempest_4(type,settings,1);
	const hitFive = magma_tempest_5(type,settings,1);
    const hitSix = magma_tempest_6(type,settings,1);
	const hitSeven = magma_tempest_7(type,settings,1);
	const hitEight = magma_tempest_8(type,settings,1);
    return  [hitOne[hitOne.length-1] + hitTwo[hitTwo.length-1] + hitThree[hitThree.length-1] + hitFour[hitFour.length-1]+hitFive[hitFive.length-1] + hitSix[hitSix.length-1] + hitSeven[hitSeven.length-1] + hitEight[hitEight.length-1]];
}

export default magma_tempest;